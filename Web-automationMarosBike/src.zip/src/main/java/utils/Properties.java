package utils;

public class Properties {
    public static String BASE_URL = "https://www.casarusu.ro/";
    public static String EMAIL = "Pop_Stan@yahoo.com";
    public static String PASSWORD = "Qpzmal123!";
    public static String wrongEMAIL = "p_Stan@yahoo.com";
    public static String secondName = "-Nelu";

}
