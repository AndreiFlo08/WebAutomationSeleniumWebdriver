package utils;

public class Messages {
    public static String welcomeMessage = "Bine ai venit în contul tău. Aici poți gestiona toate informațiile și comenzile tale.";
    public static String invalidEmailMessage =  "Autentificare esuata";
    public static String addToCartMessage = "Coș de cumpărături ";
}
